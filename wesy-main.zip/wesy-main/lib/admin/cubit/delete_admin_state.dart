part of 'delete_admin_cubit.dart';

abstract class DeleteAdminState extends Equatable {
  const DeleteAdminState();

  @override
  List<Object> get props => [];
}

class DeleteAdminInitial extends DeleteAdminState {}

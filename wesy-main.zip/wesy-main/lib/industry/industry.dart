export 'view/industry_page.dart';

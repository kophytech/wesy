class User {
  User({this.email, this.phone, this.name});

  String? email;
  String? phone;
  String? name;
}

// ignore_for_file: prefer_const_constructors
import 'package:cs_ui/cs_ui.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('CsUi', () {
    test('can be instantiated', () {
      //expect(CsUi(), isNotNull);
    });
  });
}

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'by.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

By _$ByFromJson(Map<String, dynamic> json) => By(
      id: json['id'] as String?,
      firstName: json['firstName'] as String?,
      lastName: json['lastName'] as String?,
      email: json['email'] as String?,
    );

Map<String, dynamic> _$ByToJson(By instance) => <String, dynamic>{
      'id': instance.id,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'email': instance.email,
    };

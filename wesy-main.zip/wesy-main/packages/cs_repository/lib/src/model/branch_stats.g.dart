// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'branch_stats.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BranchStats _$BranchStatsFromJson(Map<String, dynamic> json) => BranchStats(
      label: json['label'] as int?,
      count: json['count'] as int?,
    );

Map<String, dynamic> _$BranchStatsToJson(BranchStats instance) =>
    <String, dynamic>{
      'label': instance.label,
      'count': instance.count,
    };

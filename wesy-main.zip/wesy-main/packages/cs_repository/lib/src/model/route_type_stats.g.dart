// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'route_type_stats.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RouteTypeStats _$RouteTypeStatsFromJson(Map<String, dynamic> json) =>
    RouteTypeStats(
      label: json['label'] as String?,
      count: json['count'] as int?,
    );

Map<String, dynamic> _$RouteTypeStatsToJson(RouteTypeStats instance) =>
    <String, dynamic>{
      'label': instance.label,
      'count': instance.count,
    };

package com.specktre.wesy.wesy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
